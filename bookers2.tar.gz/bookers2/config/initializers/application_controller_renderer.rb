# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '92972e543f89407361d07b3a49355f099e95ad9b24d7f40f9ee1cfbcf0c84788d4aa6184c421e9ebf31e985ffaefe98fde19337d023e3ac89ceefa0b601f4aff'