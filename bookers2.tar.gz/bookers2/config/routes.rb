Rails.application.routes.draw do
  # get 'users/index'  # 削除
  # get 'users/show'   # 削除
  # get 'users/edit'   # 削除
  devise_for :users
  root to: 'homes#top'
  get 'home/about', to: 'homes#about'
  resources :users, only: [:index, :show, :edit, :update]
  resources :books, only: [:index, :show, :edit, :update, :create, :destroy]# 追加
end
